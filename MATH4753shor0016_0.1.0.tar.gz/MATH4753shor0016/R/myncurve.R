#' Normal Curve
#'
#' @param mu - population mean
#' @param sigma - standard deviation
#' @param a - upper limit of x
#'
#' @return prob - probability that x is less than a
#' @export
#'
#' @examples
#'
#' myncurve(mu=0,sigma=1,a=2)
#'
myncurve = function(mu, sigma,a){
  curve(dnorm(x,mean=mu,sd=sigma), xlim = c(mu-3*sigma, mu + 3*sigma))

  ll <- mu - 4*sigma
  ul <- a

  xcurve=seq(ll,ul,length=1000)
  ycurve=dnorm(xcurve,mean=mu,sd=sigma)
  polygon(c(ll,xcurve,ul),c(0,ycurve,0),col="red")

  prob=pnorm(ul,mean=mu,sd=sigma)
  prob=round(prob,4)

  prob
}
