#' 95% Confidence Interval
#'
#' Takes a sample x and estimates a 95% confidence interval for the population mean
#'
#' @param x sample values
#' @param alpha variable indicating desired confidence
#'
#' @return
#' @export
#'
#' @examples
#'
#' x = rnorm(30,mean=10,sd=12)
#' myci(x)
#'
myci = function(x,alpha){

  m <- mean(x)
  s <- sd(x)
  n <- length(x)
  df <- n - 1
  t <- qt((1-alpha/2),df)

  l <- m - t*s/sqrt(n)
  u <- m + t*s/sqrt(n)

  conf <- cbind(l,u)
  colnames(conf) <- c("Lower Limit","Upper Limit")
  rownames(conf) <- c("95% Confidence")
  conf
}
