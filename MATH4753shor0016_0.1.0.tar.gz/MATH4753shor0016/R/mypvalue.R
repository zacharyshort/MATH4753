#' P-Value
#'
#' @param t0 - tcalc
#' @param xmax - graphical parameter, default xmax=4
#' @param n - size of sample, default n=20
#' @param alpha - Confidence Interval: (1-alpha)
#'
#' @return
#' @export
#'
#' @examples
#'
#' x1=rnorm(30,mean=25,sd=5)
#'
#' tcalc=(mean(x1)-24)/(sd(x1)/sqrt(30))
#'
#' mypvalue(tcalc,n=30)
#'
mypvalue=function(t0,xmax=4,n=20, alpha=0.05){
  #calculate alpha/2
  va=round(pt(-t0,df=n-1),4)
  pv=2*va

  # plot the t dist
  curve(dt(x,df=n-1),xlim=c(-xmax,xmax),ylab="T Density",xlab=expression(t),
        main=substitute(paste("P-value=", pv, " alpha=", alpha)))

  q=qt(1-alpha/2,n-1)
  # set up points on the polygon to the right
  xcurve=seq(q,xmax,length=1000)
  ycurve=dt(xcurve,df=n-1)

  # set up points to the left
  xlcurve=seq(-q,-xmax,length=1000)
  ylcurve=dt(xcurve,df=n-1)

  # Shade in the polygon defined by the line segments

  polygon(c(q,xcurve,xmax),c(0,ycurve,0),col="green")
  polygon(c(-q,xlcurve,-xmax),c(0,ylcurve,0),col="green")

  abline( v=c(t0,-t0),lwd=2) # plot the cut off t value
  axis(3,c(t0,-t0),c(expression(abs(t[calc])),expression(-abs(t[calc]))))


  # Annotation
  text(0.5*(t0+xmax),max(ycurve),substitute(paste(area, "=",va)))
  text(-0.5*(t0+xmax),max(ycurve),expression(area))

  return(list(q=q,pvalue=pv))
}
